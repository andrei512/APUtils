//
//  NSDictionary+Utils.h
//
//  Created by Andrei Puni on 5/6/13.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Utils)

- (NSMutableDictionary *)merge:(NSDictionary *)dict;

@end
