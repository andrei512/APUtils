APUtils
=======

Collection of helpful categories for base obj-c classes
