//
//  UIImage+Utils.h
//
//  Created by Andrei Puni on 6/3/13.
//

#import <UIKit/UIKit.h>

@interface UIImage (Utils)

+ (UIImage *)imageWithColor:(UIColor *)color;

@end
