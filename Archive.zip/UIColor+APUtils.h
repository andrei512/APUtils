//
//  UIColor+Utils.h
//
//  Created by Andrei Puni on 4/24/13.
//

#import <UIKit/UIKit.h>

@interface UIColor (Utils)

+ (UIColor *)colorWithHex:(int)hex;

@end
