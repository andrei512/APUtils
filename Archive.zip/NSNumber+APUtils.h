//
//  NSNumber+Utils.h
//
//  Created by Andrei Puni on 5/29/13.
//

#import <Foundation/Foundation.h>

@interface NSNumber (Utils)

- (NSString *)formatedString;

- (NSString *)formatedStringWithCurrency:(NSString *)currency;

@end
