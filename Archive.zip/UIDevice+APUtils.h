//
//  UIDevice+Utils.h
//
//  Created by Andrei Puni on 6/27/13.
//

#import <UIKit/UIKit.h>

@interface UIDevice (Utils)

// iPhone, iPad, iPod, Simulator
+ (NSString *)deviceType;

@end
